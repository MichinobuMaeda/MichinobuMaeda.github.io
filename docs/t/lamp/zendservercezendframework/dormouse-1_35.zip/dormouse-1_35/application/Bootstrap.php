<?php
class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    protected function _initView()
    {
        $this->bootstrap('log');
        $logger = $this->getResource('log');
        $logger->debug(__METHOD__);
        $optAll = $this->getOptions();
        $opt = $optAll['default']['view'];
        
        // Initialize view
        $view = new Zend_View();
        $view->doctype('XHTML1_STRICT');
        $view->headMeta()
            ->appendHttpEquiv('Content-Type', 'text/html; charset=UTF-8')
            ->appendHttpEquiv('Content-Language', 'ja-JP');
        $view->headLink()
            ->appendStylesheet($opt['style']);
        $view->headTitle($opt['title']);
        $view->addHelperPath(APPLICATION_PATH."/views/helpers", "Dormouse_View_Helper_");
        $view->copyright = $opt['copyright'];
        $view->image = $opt['image'];
        
        // Add it to the ViewRenderer
        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper(
            'ViewRenderer'
        );
        $viewRenderer->setView($view);

        // Return it, so that it can be stored by the bootstrap
        return $view;
    }

    protected function _initLog()
    {
        $optAll = $this->getOptions();
        $opt = $optAll['default']['log'];
                
        // Initialize log
        $writer = new Zend_Log_Writer_Stream($opt['path']);
        $logger = new Zend_Log($writer);
        $filter = new Zend_Log_Filter_Priority(intval($opt['level']));
        $writer->addFilter($filter);
        
        $logger->debug(__METHOD__);
        
        // Return it, so that it can be stored by the bootstrap
        return $logger;
    }
}
?>
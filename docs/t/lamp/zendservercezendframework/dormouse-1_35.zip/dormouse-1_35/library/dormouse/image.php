<?php

/**
 * 画像を操作する機能を実現するクラス。
 * @author Michinobu Maeda
 */
class Dormouse_Image
{
	private $logger;
	private $opt;
	
    /**
     * コンストラクタ。
     */
    public function __construct($logger, $opt)
    {
        $this->logger = $logger;
        $this->logger->debug('Dormouse_Image->__construct()');
        $this->opt = $opt;
    }

    /**
     * 画像データをファイルに保存する。
     * @param $name ファイル名
     * @param $data データ
     */
    function save($name, $data)
    {
        $this->logger->debug('Dormouse_Image->__construct('.$name.')');
        
        $handle = fopen($this->opt['real_path'].'/'.$name, "wb");
        fwrite($handle, $data);
        fclose($handle);
    }
	
	/**
	 * @param $name ファイル名
	 * 規定のサイズに縮小する。
	 */
	public function regurateSize($name)
	{
	    $this->resize($name);
	}
	
	/**
	 * サムネイルを更新する。
	 * @param $name ファイル名
	 * @return サムネイルのファイル名。
	 */
	public function updateThumb($name)
	{
	    return $this->resize($name, TRUE);
	}
	
	/**
	 * リサイズする。
	 * @param $name ファイル名
	 * @param $is_thumb サムネイルを処理する
	 */
    protected function resize($name, $is_thumb = FALSE)
    {
        $this->logger->debug('Dormouse_Image->resize('.$name.', '.$is_thumb.')');
        $ext = strtolower(preg_replace('/.*\./', '', $name));
        $src_path = $this->opt['real_path'].'/'.$name;
        
        if ($is_thumb) {
            $trg_path = $this->opt['real_path'].'/th-'.$name;
            $ret = 'th-'.$name;
        } else {
            $trg_path = $this->opt['real_path'].'/wk-'.$name;
            $ret = $name;
        }
		
		if (($ext == 'jpeg') || ($ext == 'jpg')) {
			$image = imagecreatefromjpeg($src_path);
		} elseif ($ext == 'gif') {
			$image = imagecreatefromgif($src_path);
		} elseif ($ext == 'png') {
			$image = imagecreatefrompng($src_path);
		} else {
			copy($src_path, $trg_path);
		}
		
		$x = imagesx($image);
		$y = imagesy($image);
        
		if ($is_thumb) {
		    $max_w = $this->opt['thumb_w'];
		    $max_h = $this->opt['thumb_h'];
        } else {
		    $max_w = $this->opt['photo_w'];
		    $max_h = $this->opt['photo_h'];
        }

        if ((!$is_thumb) && ($x <= $max_w) && ($y <= $max_h)) {
            
            /* Nothing to do. */
            
        } else {
        
	        for ($i = 0; $i < 100; ++ $i) {
				if (($x * (100 - $i) / 100 <= $max_w) &&
					($y * (100 - $i) / 100 <= $max_h)) {
					$w = $x * (100 - $i) / 100;
					$h = $y * (100 - $i) / 100;
					break;
				}
			}
			
			$trg = imagecreatetruecolor($w, $h);
			imagecopyresized($trg, $image, 0, 0, 0, 0, $w, $h, $x, $y);
			
			if (($ext == 'jpeg') || ($ext == 'jpg')) {
				 imagejpeg($trg, $trg_path);
			} elseif ($ext == 'gif') {
				imagegif($trg, $trg_path);
			} elseif ($ext == 'png') {
				imagepng($trg, $trg_path);
			} else {
				copy($src_path, $trg_path);
			}
			
			imagedestroy($trg);
			
			if (!$is_thumb) {
			    rename($src_path, $this->opt['real_path'].'/org-'.$name);
			    rename($trg_path, $src_path);
			}
        }

        imagedestroy($image);
		
		return $ret;
	}

	/**
	 * イメージを回転する。
	 * @param $name ファイル名
	 * @param $degrees 角度
	 */
	public function rotate($name, $degrees)
	{
		$this->logger->debug('Dormouse_Image->rotate('.$name.', '.$degrees.')');
		$ext = strtolower(preg_replace('/.*\./', '', $name));

	    $path = $this->opt['real_path'].'/'.$name;
		
		if (($ext == 'jpeg') || ($ext == 'jpg')) {
			$source = imagecreatefromjpeg($path);
			$rotate = imagerotate($source, $degrees, 0);
			imagejpeg($rotate, $path);
		} elseif ($ext == 'gif') {
			$source = imagecreatefromgif($path);
			$rotate = imagerotate($source, $degrees, 0);
			imagegif($rotate, $path);
		} elseif ($ext == 'png') {
			$source = imagecreatefrompng($path);
			$rotate = imagerotate($source, $degrees, 0);
			imagegif($rotate, $path);
		} else {
		    return;
		}
		
		imagedestroy($source);
		imagedestroy($rotate);
		
		// サムネイルを更新する。
		$this->resize($name, TRUE);
	}
}
?>

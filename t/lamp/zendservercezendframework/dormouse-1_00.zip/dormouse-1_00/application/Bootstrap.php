<?php
require_once 'ImapConnection.php';

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    protected function _initView()
    {
        // Initialize view
        $view = new Zend_View();
        $view->doctype('XHTML1_STRICT');
        $opt = $this->getApplication()->getOptions();
        $view->headTitle($opt['app']['title']);
        $view->headLink(array(
            'rel'  => 'StyleSheet',
            'href' => $opt['app']['style'],
            'type' => 'text/css'
        ));
        $view->title = $opt['app']['title'];
        $view->copyright = $opt['app']['copyright'];
        $view->base = $opt['app']['base'];
        $view->image = $opt['app']['image'];
        
        // Add it to the ViewRenderer
        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper(
            'ViewRenderer'
        );
        $viewRenderer->setView($view);

        // Return it, so that it can be stored by the bootstrap
        return $view;
    }

    protected function _initLog()
    {
        $opt = $this->getApplication()->getOptions();
        $writer = new Zend_Log_Writer_Stream($opt['log']['path']);
        $logger = new Zend_Log($writer);
        $filter = new Zend_Log_Filter_Priority(intval($opt['log']['level']));
        $writer->addFilter($filter);
        
        $logger->debug('Bootstrap->_initLog()');
        return $logger;
    }

    protected function _initImap()
    {
        $opt = $this->getApplication()->getOptions();
        $imap = new ImapConnection(
            $opt['imap']['host'],
            $opt['imap']['port'],
            $opt['imap']['ssl'],
            $opt['imap']['user'],
            $opt['imap']['folder']
        );
        
        return $imap;
    }
}

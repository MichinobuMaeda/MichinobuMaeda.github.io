<?php
require_once 'ImapConnection.php';

/**
 * IMAPサーバで認証するアダプタ。
 * @author Michinobu Maeda
 */
class ImapAuthAdapter implements Zend_Auth_Adapter_Interface
{

	private $user;
	private $password;
	private $imap;
	private $logger;

	/**
	 * コンストラクタ。
	 * @param string $user ユーザID
	 * @param string $password パスワード
	 * @param string $imap IMAP接続
	 * @param string $logger ログ出力
	 */
	public function __construct($user, $password, $imap, $logger)
	{
        $this->logger = $logger;
		$this->logger->debug('ImapAuthAdapter->__construct()');
		$this->user = $user;
		$this->password = $password;
		$this->imap = $imap;
	}

	/**
	 * 認証する。
	 * 
	 * @throws Zend_Auth_Adapter_Exception
	 * @return Zend_Auth_Result
	 */
	public function authenticate()
	{
		$this->logger->debug('ImapAuthAdapter->authenticate()');
		
		// 認証を実行して、結果コードを設定する。
		try {
			if ($this->user != $this->imap->getUser()) {
				$code = Zend_Auth_Result::FAILURE_IDENTITY_NOT_FOUND;
				$msg = 'ユーザ不正';
			} elseif (FALSE === $this->imap->getConnection($this->password)) {
				$code = Zend_Auth_Result::FAILURE_CREDENTIAL_INVALID;
				$msg = 'IMAPサーバの認証で失敗';
			} else {
				$code = Zend_Auth_Result::SUCCESS;
				$msg = '認証成功';
			}
		} catch (Exception $e) {
		    $this->logger->err($e->getMessage());
		    $this->logger->err($e->getTraceAsString());
			throw new Zend_Auth_Adapter_Exception('認証の処理中にシステムエラーが発生しました。');
		}
	
		$this->logger->info($msg);
		return new Zend_Auth_Result($code, $this->user, array($msg));
	}
}
?>
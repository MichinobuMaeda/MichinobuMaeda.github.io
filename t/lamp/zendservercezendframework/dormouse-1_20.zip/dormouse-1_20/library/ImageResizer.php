<?php

/**
 * 画像をリサイズする機能を実現するクラス。
 * @author Michinobu Maeda
 */
class ImageResizer
{

	private $logger;
	private $name;
	private $target;
	private $opt;

	/**
	 * コンストラクタ。
	 */
	public function __construct($logger, $name, $opt, $target)
	{
        $this->logger = $logger;
		$this->logger->debug('ImageResizer->__construct()');
		$this->name = $name;
		$this->opt = $opt;
		$this->target = $target;
	}

	/**
	 * リサイズする。
	 */
    public function resize()
    {
        $this->logger->debug('ImageResizer->resize()');
        $ext = strtolower(preg_replace('/.*\./', '', $this->name));
        $src_path = $this->opt['app']['image_real'].'/'.$this->name;
        
        if ($this->target == "thumb") {
            $trg_path = $this->opt['app']['image_real'].'/th-'.$this->name;
            $ret = 'th-'.$this->name;
        } else {
            $trg_path = $this->opt['app']['image_real'].'/wk-'.$this->name;
            $ret = $this->name;
        }
		
		if (($ext == 'jpeg') || ($ext == 'jpg')) {
			$image = imagecreatefromjpeg($src_path);
		} elseif ($ext == 'gif') {
			$image = imagecreatefromgif($src_path);
		} elseif ($ext == 'png') {
			$image = imagecreatefrompng($src_path);
		} else {
			copy($src_path, $trg_path);
		}
		
		$x = imagesx($image);
		$y = imagesy($image);
        
		if ($this->target == "thumb") {
		    $max_w = $this->opt['app']['thumb_w'];
		    $max_h = $this->opt['app']['thumb_h'];
        } else {
		    $max_w = $this->opt['app']['photo_w'];
		    $max_h = $this->opt['app']['photo_h'];
        }

        if (($this->target != "thumb") && ($x <= $max_w) && ($y <= $max_h)) {
            
            /* Nothing to do. */
            
        } else {
        
	        for ($i = 0; $i < 100; ++ $i) {
				if (($x * (100 - $i) / 100 <= $max_w) &&
					($y * (100 - $i) / 100 <= $max_h)) {
					$w = $x * (100 - $i) / 100;
					$h = $y * (100 - $i) / 100;
					break;
				}
			}
			
			$trg = imagecreatetruecolor($w, $h);
			imagecopyresized($trg, $image, 0, 0, 0, 0, $w, $h, $x, $y);
			
			if (($ext == 'jpeg') || ($ext == 'jpg')) {
				 imagejpeg($trg, $trg_path);
			} elseif ($ext == 'gif') {
				imagegif($trg, $trg_path);
			} elseif ($ext == 'png') {
				imagepng($trg, $trg_path);
			} else {
				copy($src_path, $trg_path);
			}
			
			imagedestroy($trg);
			
			if ($this->target != "thumb") {
			    rename($src_path, $this->opt['app']['image_real'].'/org-'.$this->name);
			    rename($trg_path, $src_path);
			}
        }

        imagedestroy($image);
		
		return $ret;
	}
}
?>

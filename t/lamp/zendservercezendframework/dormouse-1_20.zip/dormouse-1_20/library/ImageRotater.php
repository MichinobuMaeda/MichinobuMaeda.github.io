<?php
require_once 'ImageResizer.php';

/**
 * イメージを回転する機能を実現するクラス。
 * @author Michinobu Maeda
 */
class ImageRotater
{

	private $logger;
	private $name;
	private $opt;
	private $degrees;

	/**
	 * コンストラクタ。
	 */
	public function __construct($logger, $name, $opt, $degrees)
	{
        $this->logger = $logger;
		$this->logger->debug('ImageRotater->__construct()');
		$this->name = $name;
		$this->opt = $opt;
		$this->degrees = $degrees;		
	}

	/**
	 * イメージを回転する。
	 */
	public function rotate()
	{
		$this->logger->debug('ImageRotater->rotate()');
		$ext = strtolower(preg_replace('/.*\./', '', $this->name));

	    $path = $this->opt['app']['image_real'].'/'.$this->name;
		
		if (($ext == 'jpeg') || ($ext == 'jpg')) {
			$source = imagecreatefromjpeg($path);
			$rotate = imagerotate($source, $this->degrees, 0);
			imagejpeg($rotate, $path);
		} elseif ($ext == 'gif') {
			$source = imagecreatefromgif($path);
			$rotate = imagerotate($source, $this->degrees, 0);
			imagegif($rotate, $path);
		} elseif ($ext == 'png') {
			$source = imagecreatefrompng($path);
			$rotate = imagerotate($source, $this->degrees, 0);
			imagegif($rotate, $path);
		} else {
		    return;
		}
		
		imagedestroy($source);
		imagedestroy($rotate);
		
		// サムネイルを作成する。
		$maker = new ImageResizer($this->logger, $this->name, $this->opt, "thumb");
		$maker->resize();
	}
}
?>

<?php

/**
 * imap リソースの定義。
 * @author Michinobu Maeda
 */
class Dormouse_Resource_Imap
    extends Zend_Application_Resource_ResourceAbstract
{
    public function init()
    {
        $imap = new Dormouse_Auth_Adapter_Imap(
            $this->getBootstrap()->getResource('log'),
            $this->getOptions()
        );
        
        return $imap;
    }
}
?>
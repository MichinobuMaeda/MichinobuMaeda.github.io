<?php

/**
 * log リソースの定義。
 * @author Michinobu Maeda
 */
class Dormouse_Resource_Log
    extends Zend_Application_Resource_ResourceAbstract
{
    public function init()
    {
        $opt = $this->getOptions();
        $writer = new Zend_Log_Writer_Stream($opt['path']);
        $logger = new Zend_Log($writer);
        $filter = new Zend_Log_Filter_Priority(intval($opt['level']));
        $writer->addFilter($filter);
        
        $logger->debug('Bootstrap->_initLog()');
        return $logger;
    }
}
?>
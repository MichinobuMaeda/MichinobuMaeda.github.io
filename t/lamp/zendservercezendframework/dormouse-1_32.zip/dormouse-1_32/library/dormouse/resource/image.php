<?php

/**
 * image リソースの定義。
 * @author Michinobu Maeda
 */
class Dormouse_Resource_Image
    extends Zend_Application_Resource_ResourceAbstract
{
    public function init()
    {
        $image = new Dormouse_Image(
            $this->getBootstrap()->getResource('log'),
            $this->getOptions()
        );
        
        return $image;
    }
}
?>
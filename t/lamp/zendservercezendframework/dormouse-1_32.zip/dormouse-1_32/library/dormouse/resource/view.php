<?php

/**
 * view リソースの定義。
 * @author Michinobu Maeda
 */
class Dormouse_Resource_View
    extends Zend_Application_Resource_ResourceAbstract
{
    public function init()
    {
        // Initialize view
        $view = new Zend_View();
        $view->doctype('XHTML1_STRICT');
        $opt = $this->getOptions();
        $view->headTitle($opt['title']);
        $view->headLink(array(
            'rel'  => 'StyleSheet',
            'href' => $opt['style'],
            'type' => 'text/css'
        ));
        $view->title = $opt['title'];
        $view->copyright = $opt['copyright'];
        $view->base = $opt['base'];
        $view->image = $opt['image'];
        
        // Add it to the ViewRenderer
        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper(
            'ViewRenderer'
        );
        $viewRenderer->setView($view);

        // Return it, so that it can be stored by the bootstrap
        return $view;
    }
}
?>
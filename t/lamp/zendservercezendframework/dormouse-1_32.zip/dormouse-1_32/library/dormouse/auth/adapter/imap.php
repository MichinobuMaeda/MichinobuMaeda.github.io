<?php

/**
 * IMAPサーバで認証するアダプタ。
 * @author Michinobu Maeda
 */
class Dormouse_Auth_Adapter_Imap implements Zend_Auth_Adapter_Interface
{
	private $user;
	private $password;
	private $logger;
	private $options;
	private $conn;
	
	/**
	 * コンストラクタ。
	 * @param string $logger ログ出力
	 */
	public function __construct($logger, $options)
	{
        $this->logger = $logger;
		$this->logger->debug('ImapAuthAdapter->__construct()');
        $this->options = $options;
    	$this->conn = FALSE;
	}
	
	/**
	 * 接続するユーザを設定する。
	 * @param $user ユーザ
	 */
	public function setUser($user)
	{
	    $this->user = $user;
	}
	
	/**
	 * 接続するパスワードを設定する。
	 * @param $password パスワード
	 */
	public function setPassword($password)
	{
	    $this->password = $password;
	}
	
	/**
	 * 認証する。
	 * 
	 * @throws Zend_Auth_Adapter_Exception
	 * @return Zend_Auth_Result
	 */
	public function authenticate()
	{
		$this->logger->debug('ImapAuthAdapter->authenticate()');
		
		// 認証を実行して、結果コードを設定する。
		try {
			if ($this->options['user'] != $this->user) {
				$code = Zend_Auth_Result::FAILURE_IDENTITY_NOT_FOUND;
				$msg = 'ユーザ不正';
			} else {
	    
                $param = array(
                    'host'      => $this->options['host'],
                    'port'      => intval($this->options['port']),
                    'user'      => $this->user,
                    'password'  => $this->password,
                    'folder'    => $this->options['folder']
                );
        
                if (($this->options['ssl'] == 'SSL') ||
                    ($this->options['ssl'] == 'TLS')) {

                    $param['ssl'] = $this->options['ssl'];
                }
        
                $this->conn = new Zend_Mail_Storage_Imap($param);
			    
                if (FALSE === $this->conn) {
                    $code = Zend_Auth_Result::FAILURE_CREDENTIAL_INVALID;
                    $msg = 'IMAPサーバの認証で失敗';
                } else {
                    $code = Zend_Auth_Result::SUCCESS;
                    $msg = '認証成功';
                }
			}
		} catch (Exception $e) {
		    $this->logger->err($e->getMessage());
		    $this->logger->err($e->getTraceAsString());
			throw new Zend_Auth_Adapter_Exception('認証の処理中にシステムエラーが発生しました。');
		}
	
		$this->logger->info($msg);
		return new Zend_Auth_Result($code, $this->user, array($msg));
	}

    /**
     * 接続を取得する。
     * @return Zend_Mail_Storage_Imap
     */
    public function getConnection()
    {
        return $this->conn;
    }
}
?>
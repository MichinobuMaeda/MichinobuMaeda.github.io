<?php

class Image extends Zend_Db_Table_Abstract
{
    protected $_name = 'dormouse_image';
    protected $_primary = 'id';
    protected $_sequence = true;
}

?>

<?php
require_once 'ImapAuthAdapter.php';
require_once 'Importer.php';

/**
 * 認証機能のコントローラ。
 * @author Michinobu Maeda
 */
Class AuthController extends Zend_Controller_Action
{
    protected $logger;
    protected $imap;
    protected $opt;
    
	/**
	 * インスタンスを初期化する。
	 */
	public function init()
	{
        $bootstrap = $this->getInvokeArg('bootstrap');
        $this->logger = $bootstrap->getResource('log');
        $this->logger->debug('AuthController->init()');
        $this->imap = $bootstrap->getResource('imap');
        $this->opt = $bootstrap->getApplication()->getOptions();
        $db = $bootstrap->getPluginResource('db')->getDbAdapter();
        $db->getConnection()->exec("SET NAMES 'utf8'");
	}

	/**
	 * デフォルトのアクション。
	 */
	public function indexAction()
	{
		$this->logger->debug('AuthController->indexAction()');
		
		// ログアウト処理。
		// セッションに保存されたユーザIDを破棄する。
		Zend_Auth::getInstance()->clearIdentity();
		$this->view->message = $this->_getParam('message');
	}

	/**
	 * 認証を要求するアクション。
	 */
	public function loginAction()
	{
		$this->logger->debug('AuthController->loginAction()');

		$request = $this->getRequest();

		try {
			// 認証する。
			$auth = Zend_Auth::getInstance();
			// 認証成功の場合自動的にユーザIDがセッションに保存される。
			$result = $auth->authenticate(new ImapAuthAdapter(
				$request->getParam('user'),
				$request->getParam('password'),
				$this->imap,
				$this->logger
			));
			
			if ($result->isValid()) {
				// 認証成功の場合、メールをDBに取り込んで、管理画面を表示する。
			    $importer = new Importer(
			        $this->logger,
			        $this->imap,
			        $this->opt
			    );
				$importer->import();
				$this->_forward('entrance', 'Admin', null, array(
					'list' => implode(' ', $importer->listImported())
			    ));
			} else {
				// 認証失敗の場合、ログイン画面に戻る。
				$this->_forward('index', 'auth', null, array('message' => 'ログインに失敗しました。'));
			}
		} catch (Exception $e) {
		    $this->logger->err($e->getMessage());
			$this->_forward('index', 'auth', null, array('message' => 'ログインに失敗しました。'));
		}
	}
}
?>

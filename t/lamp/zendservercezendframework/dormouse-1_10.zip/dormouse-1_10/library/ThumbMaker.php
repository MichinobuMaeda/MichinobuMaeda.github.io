<?php

/**
 * サムネイルを作成する機能を実現するクラス。
 * @author Michinobu Maeda
 */
class ThumbMaker
{

	private $logger;
	private $name;
	private $opt;

	/**
	 * コンストラクタ。
	 */
	public function __construct($logger, $name, $opt)
	{
        $this->logger = $logger;
		$this->logger->debug('ThumbMaker->__construct()');
		$this->name = $name;
		$this->opt = $opt;		
	}

	/**
	 * サムネイルを作成する。
	 */
	public function updateThumb()
	{
		$this->logger->debug('ThumbMaker->updateThumb()');
		$ext = strtolower(preg_replace('/.*\./', '', $this->name));

	    $src_path = $this->opt['app']['image_real'].'/'.$this->name;
		$thumb_path = $this->opt['app']['image_real'].'/th-'.$this->name;
		
		if (($ext == 'jpeg') || ($ext == 'jpg')) {
			$image = imagecreatefromjpeg($src_path);
		} elseif ($ext == 'gif') {
			$image = imagecreatefromgif($src_path);
		} elseif ($ext == 'png') {
			$image = imagecreatefrompng($src_path);
		} else {
			copy($src_path, $thumb_path);
		}
		
		$x = imagesx($image);
		$y = imagesy($image);
		for ($i = 0; $i < 100; ++ $i) {
			if (($x * (100 - $i) / 100 <= $this->opt['app']['thumb_w']) &&
				($y * (100 - $i) / 100 <= $this->opt['app']['thumb_h'])) {
				$w = $x * (100 - $i) / 100;
				$h = $y * (100 - $i) / 100;
				break;
			}
		}
		
		$thumb = imagecreatetruecolor($w, $h);
		imagecopyresized($thumb, $image, 0, 0, 0, 0, $w, $h, $x, $y);
		
		if (($ext == 'jpeg') || ($ext == 'jpg')) {
			 imagejpeg($thumb, $thumb_path);
		} elseif ($ext == 'gif') {
			imagegif($thumb, $thumb_path);
		} elseif ($ext == 'png') {
			imagepng($thumb, $thumb_path);
		} else {
			copy($src_path, $thumb_path);
		}
		
		imagedestroy($image);
		imagedestroy($thumb);
		
		return 'th-'.$this->name;
	}
}
?>

<?php

/**
 * IMAPサーバの接続。
 * @author Michinobu Maeda
 */
class ImapConnection
{

	private $host;
	private $port;
	private $ssl;
	private $user;
	private $folder;
	private $conn;
	
	/**
	 * コンストラクタ。
	 * @param string $host ホスト
	 * @param string $port ポート
	 * @param string $ssl  暗号化方式
	 * @param string $user ユーザID
	 * @param string $folder 処理対象フォルダ
	 */
	public function __construct($host, $port, $ssl, $user, $folder)
	{
		
	    $this->host = $host;
    	$this->port = $port;
		$this->ssl = $ssl;
    	$this->user = $user;
    	$this->folder = $folder;
    	$this->conn = FALSE;
	}

	/**
	 * 接続を取得する。
	 *
	 * @param string $password パスワード
	 * @return Zend_Auth_Result
	 */
	public function getConnection($password = null)
	{
	    
	    // 接続済みの場合
	    if ($this->conn !== FALSE) {
	        return $this->conn;
	    }

	    if (($this->ssl == 'SSL') ||
			($this->ssl == 'TLS')) {

			$this->conn = new Zend_Mail_Storage_Imap(
				array(
					'host' 		=> $this->host,
					'port' 		=> intval($this->port),
					'user'		=> $this->user,
					'password'	=> $password,
					'ssl'		=> $this->ssl));
		} else {

			$this->conn = new Zend_Mail_Storage_Imap(
				array(
					'host' 		=> $this->host,
					'port' 		=> intval($this->port),
					'user'		=> $this->user,
					'password'	=> $password));
		}

		// IMAPサーバのフォルダを選択する。
		$is_folder = FALSE;
		$folders = new RecursiveIteratorIterator(
			$this->conn->getFolders(),
			RecursiveIteratorIterator::SELF_FIRST
		);
		
		// 処理対象のフォルダを取得する。
		foreach ($folders as $localName => $fol) {
			if ($fol->getGlobalName() != $this->folder) continue;
			$is_folder = TRUE;
			$this->conn->selectFolder($fol);
			break;
		}
		
		if (!$is_folder) {
			$this->logger->err('Failed to find '.$folname);
		}
		
	    return $this->conn;
	}

	/**
	 * ユーザを取得する。
	 * @return string
	 */
	public function getUser()
	{
	    return $this->user;
	}
}
?>
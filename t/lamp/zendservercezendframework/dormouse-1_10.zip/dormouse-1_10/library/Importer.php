<?php
require_once 'ThumbMaker.php';
require_once APPLICATION_PATH."/models/Blog.php";
require_once APPLICATION_PATH."/models/Image.php";

/**
 * メールをDBに取り込む機能を実現するクラス。
 * @author Michinobu Maeda
 */
class Importer
{

	private $logger;
	private $mail;
	private $opt;
	private $list = array();

	/**
	 * コンストラクタ。
	 */
	public function __construct($logger, $imap, $opt)
	{
        $this->logger = $logger;
        $this->mail = $imap->getConnection();
        $this->opt = $opt;
        $this->logger->debug('Importer->__construct()');
	}

	/**
	 * メールをDBに取り込む。
	 */
	public function import()
	{
		$this->logger->debug('Importer->import()');
			
        $blog = new Blog();
        $image = new Image();	        

		// メッセージ毎に処理する。
		foreach ($this->mail as $num => $message) {
			$this->importMessage($message, $blog, $image);
		}
	}
	
	/**
	 * メッセージがDBに保存されていなければ保存する。
	 * @param Zend_Mail_Message $message メッセージ
	 */
	private function importMessage($message, $blog, $image)
	{
		//$this->logger->debug('Importer->importMessage()');
		
		// メッセージIDを取得する。
		$id = $message->messageId;

		// メッセージIDがDBに保存されていることを確認する。
		$select = $blog->select()->where('message_id = ?', $id);
		$rows = $blog->fetchAll($select);

		// DBに保存されている場合、処理を終了する。
		if (count($rows) > 0) {
			return;
		}
		
		// Subject を取得する。
		try {
			$subject = mb_decode_mimeheader($message->subject);
		} catch (Exception $e) {
		    $this->logger->warn($e);
		    $subject = '(no subject)';
		}

		// Date を取得する。
		try {
		    $date = new DateTime($message->date);
		} catch (Exception $e) {
		    $this->logger->warn($e);
		    $date = new DateTime($message->date);
		}

		// Body を取得する。
		$body = '';
		if ($message->isMultipart()) {
		foreach (new RecursiveIteratorIterator($message) as $part) {
				try {
					if (strtok($part->contentType, ';') == 'text/plain') {
						$body .= mb_convert_encoding($part->getContent(), 'UTF-8', 'JIS');
					}
				} catch (Zend_Mail_Exception $e) { }
			}
			
		} else {
			$body = mb_convert_encoding($message->getContent(), 'UTF-8', 'JIS');
		}
		
		if (!$body) {
			$body = '(empty)';
		}

		// テーブル dormouse_blog に保存する。
		$pk = $blog->insert(array(
			'message_id' => $id,
			'date'       => $date->format('Y/m/d H:m:s'),
			'subject'    => $subject,
			'body'       => $body
		));

		array_push($this->list, $pk);
		$this->logger->info('dormouse_blog.id:'.$pk);

		// 添付ファイルの画像を取得する。
		$imgcnt = 0;

		if ($message->isMultipart()) {
			foreach (new RecursiveIteratorIterator($message) as $part) {
				try {
					$type = strtok($part->contentType, ';');

					if (!preg_match("/^image\\//", $type)) { continue; }

					// ファイルのタイプから拡張子を決定する。
					$ext = preg_replace("/^image\\//", '', $type);
					
					// 画像をファイルとして保存する。
					++ $imgcnt;
					$name = $pk.'-'.$imgcnt;
					$this->logger->info($name.'.'.$ext);
					$handle = fopen($this->opt['app']['image_real'].'/'.$name.'.'.$ext, "wb");
					fwrite($handle, imap_base64($part->getContent()));
					fclose($handle);
					
					// サムネイルを作成する。
					$maker = new ThumbMaker($this->logger, $name.'.'.$ext, $this->opt);
					$thumb_path = $maker->updateThumb();
					
					// テーブル dormouse_image に保存する。
					$pk = $image->insert(array(
						'blog_id'    => $pk,
						'full'       => $name.'.'.$ext,
						'thumb'      => $thumb_path
					));
					
					$this->logger->info('dormouse_image.id:'.$pk);

				} catch (Exception $e) {
					$this->logger->err($e);
				}
			}
			
		}
	}
	
	/**
	 * DBに追加したキーのリストを取得する。
	 * @return array
	 */
	public function listImported()
	{
		return $this->list;
	}
}
?>
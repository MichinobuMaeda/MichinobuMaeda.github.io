<?php
require_once APPLICATION_PATH."/models/Image.php";

class Blog extends Zend_Db_Table_Abstract
{
    protected $_name = 'dormouse_blog';
    protected $_primary = 'id';
    protected $_sequence = true;
    
    /**
     * 最新のIDを取得する。
     * @return string
     */
    public function getLatestId() 
    {
        $select = $this->select()
            ->where('visible = 1')
            ->order('date DESC')
            ->limit(1);
        $rows = $this->fetchAll($select);
        return $rows[0]['id'];
    }

    /**
     * 目次用のリストを取得する。
     * @return array
     */
    public function getList()
    {
        $select = $this->select()
            ->where('visible = 1')
            ->order('date DESC');
        $rows = $this->fetchAll($select);

        $ret = array();
        $image = new Image();
        
        for ($i = 0; $i < count($rows); ++ $i) {
            
            $ret[$i] = array(
                'id' => $rows[$i]['id'],
                'date' => $rows[$i]['date'],
                'subject' => $rows[$i]['subject'],
                'thumb' => array()
            );
            
	        $select = $image->select()
	            ->where('blog_id = '.$rows[$i]['id'])
	            ->order('id');
	        $iamge_rows = $image->fetchAll($select);
	        foreach ($iamge_rows as $iamge_row) {
	            array_push($ret[$i]['thumb'], $iamge_row['thumb']);
	        }
        }
        
        return $ret;
    }
    
    /**
     * IDのリストに対応する行を取得する。
     * @param array $list IDのリスト
     * @return array 結果行
     */
    public function getListByIds($list)
    {
        $ret = array();
                
    	foreach ($list as $key => $val) {

		    if (!$val) { continue; }
			$rows = $this->find($val);
	        array_push($ret, $rows[0]);
    	}
    	return $ret;
    }
    
    /**
     * カラム prev, next を一括で更新する。
     */
    public function updateSequence()
    {
        $select = $this->select()
            ->order('date DESC');
		$rows = $this->fetchAll($select);
		$prev = 0;
		
		foreach ($rows as $row) {

		    if ($row['visible'] == 0) {
		        $this->update(array('prev' => 0, 'next' => 0), 'id = '.$row['id']);
		    } else {
		        $this->update(array('prev' => $prev, 'next' => 0), 'id = '.$row['id']);
		        $this->update(array('next' => $row['id']), 'id = '.$prev);
		        $prev = $row['id'];
		    }
 		}
    }
}

?>

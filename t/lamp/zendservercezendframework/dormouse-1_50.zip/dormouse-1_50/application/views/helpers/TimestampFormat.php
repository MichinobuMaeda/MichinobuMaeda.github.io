<?php
class Dormouse_View_Helper_TimestampFormat extends Zend_View_Helper_Abstract
{
    public function timestampFormat($date = FALSE, $format = null)
    {
        $ret = new Zend_Date($date, $format);
        return $this->view->escape($ret->toString("yyyy-MM-dd HH:mm:ss"));
    }    
}
?>
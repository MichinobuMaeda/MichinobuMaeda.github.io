<?php
class Dormouse_View_Helper_JapaneseDateFormat extends Zend_View_Helper_Abstract
{
    public function japaneseDateFormat($date = FALSE, $format = null)
    {
        $ret = new Zend_Date($date, $format);
        return $this->view->escape($ret->toString("yyyy年M月d日"));
    }    
}
?>
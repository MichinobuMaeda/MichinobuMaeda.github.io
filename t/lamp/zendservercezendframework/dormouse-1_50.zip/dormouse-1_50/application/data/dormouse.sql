CREATE TABLE "dormouse_blog" ("id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , "message_id" TEXT, "date" DATETIME, "subject" TEXT, "body" TEXT, "visible" BOOL, "prev" INTEGER, "next" INTEGER)
CREATE TABLE "dormouse_image" ("id" INTEGER PRIMARY KEY  AUTOINCREMENT  NOT NULL , "blog_id" INTEGER, "full" TEXT, "thumb" TEXT, "visible" BOOL)

<?php
require_once APPLICATION_PATH."/models/Blog.php";
require_once APPLICATION_PATH."/models/Image.php";

class IndexController extends Zend_Controller_Action
{
    protected $logger;
    
	/**
	 * インスタンスを初期化する。
	 */
    public function init()
    {
	    $bootstrap = $this->getInvokeArg('bootstrap');
        // -- only for MySQL -- $bootstrap->getPluginResource('db')->getDbAdapter()->getConnection()->exec("SET NAMES 'utf8'");
        $this->logger = $bootstrap->getResource('log');
        $this->logger->debug(__METHOD__);
    }

	/**
	 * デフォルトのアクション。
	 */
    public function indexAction()
    {
        $this->logger->debug(__METHOD__);
                
		// リクエスト内容を取得する。
		$request = $this->getRequest();
		$id = $request->getParam('id');
		$this->logger->debug('request id: '.$id);
		
		// テーブル dormouse_blog からデータを取得する。
		$blog = new Blog();
		
		// リクエストパラメータでIDが指定されていない場合は最新を表示する。
		if (!is_numeric($id)) {
		    $id = $blog->getLatestId();
		    $this->logger->debug('latest id: '.$id);
		}

		// DBにデータが登録されていない場合は、データが無い旨表示する。
		if (!is_numeric($id)) {
	        $this->_forward('nodata', 'index');
	        return;
		}

		$blogs = $blog->find($id);
		$this->view->blog = $blogs[0];

		// テーブル dormouse_image からデータを取得する。
		$image = new Image();
		$select = $image->select()
		    ->where('blog_id = ?', $id)
		    ->order('id');
		$this->view->images = $blog->fetchAll($select);
    }

	/**
	 * リストを表示する。
	 */
    public function listAction()
    {
        $this->logger->debug(__METHOD__);
        		
		// テーブル dormouse_blog からデータを取得する。
		$blog = new Blog();
		$this->view->list = $blog->getList();
    }
    
	/**
	 * データが無い旨表示する。
	 */
    public function nodataAction()
    {
        $this->logger->debug(__METHOD__);
    }
}

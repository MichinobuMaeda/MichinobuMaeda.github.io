<?php
require_once APPLICATION_PATH."/models/Blog.php";
require_once APPLICATION_PATH."/models/Image.php";

/**
 * 認証機能のコントローラ。
 * @author Michinobu Maeda
 */
Class Priv_IndexController extends Zend_Controller_Action
{
    protected $logger;
    protected $imap;
    protected $image;
    
	/**
	 * インスタンスを初期化する。
	 */
	public function init()
	{
	    $bootstrap = $this->getInvokeArg('bootstrap');
        // -- only for MySQL -- $bootstrap->getPluginResource('db')->getDbAdapter()->getConnection()->exec("SET NAMES 'utf8'");
        $this->logger = $bootstrap->getResource('log');
        $this->logger->debug(__METHOD__);
        $moduleBootstraps = $bootstrap->getPluginResource('modules')->getExecutedBootstraps();
        $bootstrap = $moduleBootstraps['priv'];
        $this->imap = $bootstrap->getResource('imap');
        $this->image = $bootstrap->getResource('image');
	}

	/**
	 * デフォルトのアクション。
	 */
	public function indexAction()
	{
		$this->logger->debug(__METHOD__);
		
		// ログアウト処理。
		// セッションに保存されたユーザIDを破棄する。
		Zend_Auth::getInstance()->clearIdentity();
		$this->view->message = $this->_getParam('message');
	}

	/**
	 * 認証を要求するアクション。
	 */
	public function loginAction()
	{
		$this->logger->debug(__METHOD__);
	    
		$request = $this->getRequest();

		try {
			// 認証する。
			$auth = Zend_Auth::getInstance();
			$this->imap->setUser($request->getParam('user'));
			$this->imap->setPassword($request->getParam('password'));
			// 認証成功の場合自動的にユーザIDがセッションに保存される。
			$result = $auth->authenticate($this->imap);
			
			if ($result->isValid()) {
				// 認証成功の場合、メールをDBに取り込んで、管理画面を表示する。
				$blog = new Blog();
				$image = new Image();
				
				// メッセージ毎に処理する。
				$list = array();
				
				foreach ($this->imap->getConnection() as $num => $message) {
				    $pk = $this->importMessage($message, $blog, $image);
				    array_push($list, $pk);
				}
			    
				$this->_forward('entrance', 'admin', 'priv', array(
					'list' => implode(' ', $list)
			    ));
			} else {
				// 認証失敗の場合、ログイン画面に戻る。
				$this->_forward('index', 'index', 'priv', array('message' => 'ログインに失敗しました。'));
			}
		} catch (Exception $e) {
		    $this->logger->err($e->getMessage());
			$this->_forward('index', 'index', 'priv', array('message' => 'ログインに失敗しました。'));
		}
	}
	
	/**
	 * メッセージがDBに保存されていなければ保存する。
	 * @param Zend_Mail_Message $message メッセージ
	 */
	private function importMessage($message, $blog, $image)
	{
		//$this->logger->debug(__METHOD__);
	    				
		// メッセージIDを取得する。
		$id = $message->messageId;

		// メッセージIDがDBに保存されていることを確認する。
		$select = $blog->select()->where('message_id = ?', $id);
		$rows = $blog->fetchAll($select);

		// DBに保存されている場合、処理を終了する。
		if (count($rows) > 0) {
			return;
		}
		
		// Subject を取得する。
		try {
			$subject = mb_decode_mimeheader($message->subject);
		} catch (Exception $e) {
		    $this->logger->warn($e);
		    $subject = '(no subject)';
		}

		// Date を取得する。
		try {
		    $date = new Zend_Date($message->date, Zend_Date::RFC_2822, 'en_US');
		} catch (Exception $e) {
		    $this->logger->warn($e);
		    $date = Zend_Date::now();
		}

		// Body を取得する。
		$body = '';
		if ($message->isMultipart()) {
		foreach (new RecursiveIteratorIterator($message) as $part) {
				try {
					if (strtok($part->contentType, ';') == 'text/plain') {
						$body .= mb_convert_encoding($part->getContent(), 'UTF-8', 'JIS');
					}
				} catch (Zend_Mail_Exception $e) { }
			}
			
		} else {
			$body = mb_convert_encoding($message->getContent(), 'UTF-8', 'JIS');
		}
		
		if (!$body) {
			$body = '(empty)';
		}

		// テーブル dormouse_blog に保存する。
		$pk = $blog->insert(array(
			'message_id' => $id,
			'date'       => $date->toString('yyyy/MM/dd HH:mm:ss'),
			'subject'    => $subject,
			'body'       => $body
		));

		$ret = $pk;
		$this->logger->info('dormouse_blog.id:'.$pk);

		// 添付ファイルの画像を取得する。
		$imgcnt = 0;

		if ($message->isMultipart()) {
			foreach (new RecursiveIteratorIterator($message) as $part) {
				try {
					$type = strtok($part->contentType, ';');

					if (!preg_match("/^image\\//", $type)) { continue; }

					// ファイルのタイプから拡張子を決定する。
					$ext = preg_replace("/^image\\//", '', $type);
					
					// 画像をファイルとして保存する。
					++ $imgcnt;
					$name = $pk.'-'.$imgcnt;
					$this->image->save($name.'.'.$ext, imap_base64($part->getContent()));
					
					// 画像サイズを調整する。
					$this->image->regurateSize($name.'.'.$ext);
					
					// サムネイルを作成する。
					$thumb_path = $this->image->updateThumb($name.'.'.$ext);
					
					// テーブル dormouse_image に保存する。
					$pk = $image->insert(array(
						'blog_id'    => $pk,
						'full'       => $name.'.'.$ext,
						'thumb'      => $thumb_path
					));
					
					$this->logger->info('dormouse_image.id:'.$pk);

				} catch (Exception $e) {
					$this->logger->err($e);
				}
			}
			
		}
		
		return $ret;
	}
}
?>

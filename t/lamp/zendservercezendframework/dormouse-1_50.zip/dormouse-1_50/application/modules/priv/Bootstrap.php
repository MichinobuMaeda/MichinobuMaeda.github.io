<?php
class Priv_Bootstrap extends Zend_Application_Module_Bootstrap
{
    public function _initImap()
    {
        $this->getApplication()->bootstrap('log');
        $logger = $this->getApplication()->getResource('log');
        $logger->debug(__METHOD__);
        $opt = $this->getApplication()->getOptions();
        
        $imap = new Dormouse_Auth_Adapter_Imap($logger, $opt['priv']['imap']);
        
        return $imap;
    }

    public function _initImage()
    {
        $this->getApplication()->bootstrap('log');
        $logger = $this->getApplication()->getResource('log');
        $logger->debug(__METHOD__);
        $opt = $this->getApplication()->getOptions();
        
        $image = new Dormouse_Image($logger, $opt['priv']['image']);
        
        return $image;
    }
}
?>
<?php
require_once APPLICATION_PATH."/models/Blog.php";
require_once APPLICATION_PATH."/models/Image.php";

/**
 * 管理機能のコントローラ。
 * @author Michinobu Maeda
 */
Class Priv_AdminController extends Zend_Controller_Action
{
    protected $logger;
    protected $image;
    
	/**
	 * インスタンスを初期化する。
	 */
	public function init()
	{
	    $bootstrap = $this->getInvokeArg('bootstrap');
        // -- only for MySQL -- $bootstrap->getPluginResource('db')->getDbAdapter()->getConnection()->exec("SET NAMES 'utf8'");
        $this->logger = $bootstrap->getResource('log');
        $this->logger->debug(__METHOD__);
        $moduleBootstraps = $bootstrap->getPluginResource('modules')->getExecutedBootstraps();
        $bootstrap = $moduleBootstraps['priv'];
        $this->image = $bootstrap->getResource('image');
	}

	/**
	 * デフォルトのアクション。
	 */
	public function indexAction()
	{
        $this->logger->debug(__METHOD__);
	    	    		
		$blog = new Blog();
		$select = $blog->select()
		    ->order('date DESC');
		$this->view->list = $blog->fetchAll($select);
	}

	/**
	 * 編集アクション。
	 */
	public function editAction()
	{
        $this->logger->debug(__METHOD__);
	    	    
		// リクエスト内容を取得する。
		$request = $this->getRequest();
		$id = $request->getParam('id');
		$this->logger->debug('request id: '.$id);
		$this->view->message = $request->getParam('message');
		
		// テーブル dormouse_blog からデータを取得する。
		$blog = new Blog();
		$blogs = $blog->find($id);
		$this->view->blog = $blogs[0];

		// テーブル dormouse_image からデータを取得する。
		$image = new Image();
		$select = $image->select()
		    ->where('blog_id = ?', $id)
		    ->order('id');
		$this->view->images = $blog->fetchAll($select);
	}

	/**
	 * 更新アクション。
	 */
	public function updateAction()
	{
        $this->logger->debug(__METHOD__);
	    	    		
		// 更新内容を取得する。
		$request = $this->getRequest();
		$id = $request->getParam('id');
		$visible = ($request->getParam('visible') ? 1 : 0);
		$subject = $request->getParam('subject');
		$body = $request->getParam('body');
		$image_ids = $request->getParam('image_id');
		$image_visible = array();
		$image_rotate = array();
		$image_full = array();
		if (count($image_ids) == 1) {
			$image_visible[$image_ids] = $request->getParam('image_visible_'.$image_ids);
			$image_rotate[$image_ids]  = $request->getParam('image_rotate_'.$image_ids);
			$image_full[$image_ids]  = $request->getParam('image_full_'.$image_ids);
		} else {
			foreach ($image_ids as $image_id) {
				$image_visible[$image_id] = $request->getParam('image_visible_'.$image_id);
				$image_rotate[$image_id]  = $request->getParam('image_rotate_'.$image_id);
			    $image_full[$image_id]  = $request->getParam('image_full_'.$image_id);
			}
		}
		
		$this->logger->debug('update id: '.$id);
		
		// テーブル dormouse_blog を更新する。
		$blog = new Blog();
		$blog->update(array(
		        'subject' => $subject,
				'body' => $body,
		        'visible' => $visible
		    ), 'id = '.$id
		);
		$blog->updateSequence();

		// テーブル dormouse_image を更新する。
		$image = new Image();
		foreach ($image_visible as $image_id => $val) {
			$image->update(array(
			        'visible' => ($val ? 1 : 0)
			    ), 'id = '.$image_id
			);
		}
		
		// イメージを回転する。
		foreach ($image_rotate as $image_id => $val) {
		    if ($val == 0) { continue; }
		    $this->image->rotate($image_full[$image_id], $val);
		}
		
		// 編集画面に戻る。　
		$this->_forward('edit', 'Admin', null, array('message' => '更新しました。'));
	}
	
	/**
	 * ログイン直後のアクション。
	 */
	public function entranceAction()
	{
        $this->logger->debug(__METHOD__);
	    	    		
		// DBに新規追加されたIDのリストを取得する。
		$blog = new Blog();
		$this->view->list = $blog->getListByIds(explode(' ', $this->_getParam('list')));
	}
	
	/**
	 * ディスパッチ実行前の処理。
	 */
	public function preDispatch()
	{
        $this->logger->debug(__METHOD__);
	    		
		// ログインしていない場合ログイン画面に戻る。
		if (!Zend_Auth::getInstance()->hasIdentity()) {
			$this->logger->debug("_forward('index', 'auth', 'priv)");
			$this->_forward('index', 'auth', 'priv');
		}
	}
}
?>
